package open_bootcamp;

public class main {

    public static void main(String[] args){
        int numeroWhile  =3;

        while (numeroWhile  >0){
            System.out.println(numeroWhile );
            numeroWhile  = numeroWhile  -1;
        }
    }
 }