package Do_While;

public class main {

    public static void main(String[] args){
        int numeroWhile = 3;

        do {
            System.out.println(numeroWhile);
            numeroWhile = numeroWhile -1;
        } while (numeroWhile>2);
    }
}